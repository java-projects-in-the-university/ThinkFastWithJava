
package thinkfastwithjava;

import java.io.IOException;
import java.sql.Connection;
import java.util.Timer;
import java.util.logging.Level;
import java.util.logging.Logger;


public class main {
    public static void main(String[] args) throws IOException {
      JavaGameForm frame = new JavaGameForm(); 
        PlayerInfo p1 = new PlayerInfo();
        p1.isPlayerExist("Aliaa");
       Timer timer = new Timer();

            p1.readInFile();

     
    } 
}
