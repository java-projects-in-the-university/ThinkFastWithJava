package thinkfastwithjava;

import java.sql.*;
import java.util.*;


public class PlayerInfo {
   
    protected String playerName;
    protected int playerPoints;
    protected int Previouspointst;
    Level levels;
    /**
     * Set the value of playerName
     *
     * @param playerNamet new value of playerName
     */
   public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }
   
   /**
     * Set the value of playerPoints
     *
     * @param playerPoints new value of playerPoints
     */
   public void setPlayerPoints(int playerPoints) {
        this.playerPoints = playerPoints;
    }


    /**
     * Set the value of Previouspointst
     *
     * @param Previouspointst new value of Previouspointst
     */
    public void setPreviouspointst(int Previouspointst) {
        this.Previouspointst = Previouspointst;
    }
    /**
     * Set the value of levels
     *
     * @param levels new value of levels
     */
     public void setLevels(Level levels) {
        this.levels = levels;
    } 

    
    /**
     * Get the value of playerName
     *
     * @return the value of playerName
     */
 
    public String getPlayerName() {
        return playerName;
    }
    
    
    /**
     * Get the value of playerPoints
     *
     * @return the value of playerPoints
     */

    public int getPlayerPoints() {
        return playerPoints;
    }
    
     /**
     * Get the value of Previouspointst
     *
     * @return the value of Previouspointst
     */
    public int getPreviouspointst() {
        return Previouspointst;
    }
    /**
     * Get the value of levels
     *
     * @return the value of levels
     */
    
    public Level getLevels() {
        return levels;
    }

   
    
    public boolean isPlayerExist(String PlayerName){
        boolean exist = false;
        Connection con = null;
        PreparedStatement s = null;
        ResultSet rs = null;
           try{
                con = Connect.getConnection();
                String select = "SELECT PlayerName FROM think_fast_with_java.player WHERE PlayerName = ?;";
                s = con.prepareStatement(select);
                s.setString(1, PlayerName);
                rs = s.executeQuery();
                if(rs.next()){
                    exist = true;
                    //System.out.println("Too Bad This Name is Taken!!");
                }
                else{
                    exist = false;
                    //System.out.println("Nice Name!!"); 
                }
           }
           catch(Exception e){
               e.printStackTrace();
           }
           finally{
               if(rs != null) try{rs.close();}catch(Exception e){e.printStackTrace();}
               if(s != null) try{s.close();}catch(Exception e){e.printStackTrace();}
               if(con != null) try{con.close();}catch(Exception e){e.printStackTrace();}
           }        
        return exist;
    }
    public void savePlayerInfo( String playerName){
        Connection con = null;
        PreparedStatement s = null;
        String query;
           try{
               con = Connect.getConnection();
               if( this.isPlayerExist( playerName)){
                 query = "UPDATE player SET  PlayerName = ? WHERE PlayerName = ? ";
                 System.out.println("PlayerName "+playerName+" is exist ");
               
               }    
            else {
                query = " INSERT INTO player (PlayerName,Previouspointst,PlayerScore,Level) VALUES (?,?,?,?)";
                System.out.println("PlayerName "+playerName +" NOT exist ");
            }
            // apply query 
            s= con.prepareStatement(query);
            s.setString(1,playerName);
            s.setInt(2,0);
            s.setInt(3,0);
            s.setInt(4,1);
            int resutl = s.executeUpdate();
            System.out.println(" Result = 1 PlayerName record has been Sucessfully saved ");
          }
            catch (Exception e ){
              System.out.println("Saving one PlayerName record was NOT sucessful");
              e.printStackTrace();
                    //System.out.println("Nice Name!!"); 
            }
         
           finally{
               if(s != null) try{s.close();}catch(Exception e){e.printStackTrace();}
               if(con != null) try{con.close();}catch(Exception e){e.printStackTrace();}
           }
    }
    
    public static PlayerInfo loadPlayerInfo(String PlayerName){
        Connection con = null;
        PreparedStatement s = null;
        ResultSet rs = null;
        PlayerInfo playerInfo=new PlayerInfo();
        try{
             con = Connect.getConnection();
             String select = "SELECT * FROM player WHERE PlayerName = ?;";
             s = con.prepareStatement(select);
             s.setString(1,PlayerName);
             rs = s.executeQuery();
              if(rs.next()){
                playerInfo.setPlayerName(PlayerName);
                playerInfo.setPlayerPoints(rs.getInt("PlayerScore"));
                playerInfo.setPreviouspointst(rs.getInt("Previouspointst"));
                int LevelNum= rs.getInt("Level");
                Level le=Level.loadLevelInfo(LevelNum);
                playerInfo.setLevels(le);
               System.out.println("LevelNum");
              }
            
              
           }
           catch(Exception e){
             e.printStackTrace();
             System.out.println("LNum");
           }
           finally{
               if(rs != null) try{rs.close();}catch(Exception e){e.printStackTrace();}
               if(s != null) try{s.close();}catch(Exception e){e.printStackTrace();}
               if(con != null) try{con.close();}catch(Exception e){e.printStackTrace();}
           }        
        return null;
    }
    public void updatePlayerInfo(int playerPoints, int level ,int BeginnerPoint,int MeduimPoint,int AdvancedPoint,int Professional ) {
        Connection con = null;
        PreparedStatement s = null;
        String query;
        try {
             con = Connect.getConnection();
            query = "UPDATE player SET BeginnerPoint=? MeduimPoint=? AdvancedPoint=? Professional=?PlayerScore=? and Level=? WHERE PlayerName = ? ";
            s = con.prepareStatement(query);
            s.setString(7, this.getPlayerName());
            s.setInt(1, BeginnerPoint);
            s.setInt(2, MeduimPoint);
            s.setInt(3, AdvancedPoint);
            s.setInt(4, Professional);
            s.setInt(5, playerPoints);
            s.setInt(6,level);
            int result = s.executeUpdate();
       } 
        catch (Exception e) {
            e.printStackTrace();
        } 
        finally {
            if(s != null)try{s.close();}catch(Exception e){e.printStackTrace();}
            if(con != null)try{con.close();}catch(Exception e){e.printStackTrace();}
        } 
    } 
     public void deleatPlayerInfo(int playerPoints, int level ){
         Connection con = null;
        PreparedStatement s = null;
        String query;
        try {
             con = Connect.getConnection();
            query = "Delete from player where PlayerName = ? ;";
            s = con.prepareStatement(query);
            s.setString(3, this.getPlayerName());
            int result = s.executeUpdate();
       } 
        catch (Exception e) {
            e.printStackTrace();
        } 
        finally {
            if(s != null)try{s.close();}catch(Exception e){e.printStackTrace();}
            if(con != null)try{con.close();}catch(Exception e){e.printStackTrace();}
        } 
         
     }
    
    
}

