/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thinkfastwithjava;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;

/**
 *
 * @author saleh
 */
public class Level {

  
    int LevelNum;
    String LevelName;
    int maxPoints;
    Vector<Questions> questions;
    
    public Level() {
       questions = new Vector<Questions>();
    }

    public void setLevelNum(int LevelNum) {
        this.LevelNum = LevelNum;
    }

    public void setLevelName(String LevelName) {
        this.LevelName = LevelName;
    }

    public void setMaxPoints(int maxPoints) {
        this.maxPoints = maxPoints;
    }

    public void setQuestions(Vector<Questions> questions) {
        this.questions = questions;
    }

    public int getLevelNum() {
        return LevelNum;
    }

    public String getLevelName() {
        return LevelName;
    }

    public int getMaxPoints() {
        return maxPoints;
    }
    public void addQuestions (Questions q){
      questions.add(q);
    } 

    public Vector<Questions> getQuestions() {
        return questions;
    }
    public static Level loadLevelInfo(int LevelNum){
        Connection con = null;
        PreparedStatement s = null;
        ResultSet rs = null;
        Level level=new Level();
        try{
             con = Connect.getConnection();
             String select = "SELECT * FROM think_fast_with_java.levels WHERE LevelNum = ?;";
             s = con.prepareStatement(select);
             s.setInt(1, LevelNum);
             rs = s.executeQuery();
              if(rs.next()){ 
                 level.setLevelNum(LevelNum);
                 level.setLevelName(rs.getString("LevelName"));
                 level.setMaxPoints(rs.getInt("maxPoints"));
                 Vector<Questions> sList= Questions.loadQuestionInfo(LevelNum);
                if(sList != null){
                    for(Questions sc : sList){
                       level.addQuestions(sc);
                        sc.setLevel(level);
                    }
                           
                }
              }
            
              else{
                    
                }
           }
           catch(Exception e){
               e.printStackTrace();
           }
           finally{
               if(rs != null) try{rs.close();}catch(Exception e){e.printStackTrace();}
               if(s != null) try{s.close();}catch(Exception e){e.printStackTrace();}
               if(con != null) try{con.close();}catch(Exception e){e.printStackTrace();}
           }        
        return null;
    }

    
    
    
    
     
    
}