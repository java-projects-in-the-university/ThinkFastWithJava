/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thinkfastwithjava;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Random;
import java.util.Vector;

/**
 *
 * @author saleh
 */
public class Questions {
    Level level;
    int QuestionNum;
    String QuestionContent;
    String Solution1;
    String Solution2;

    public void setLevel(Level level) {
        this.level = level;
    }

    public void setQuestionNum(int QuestionNum) {
        this.QuestionNum = QuestionNum;
    }

    public void setQuestionContent(String QuestionContent) {
        this.QuestionContent = QuestionContent;
    }

    public void setSolution1(String Solution1) {
        this.Solution1 = Solution1;
    }

    public void setSolution2(String Solution2) {
        this.Solution2 = Solution2;
    }

    public Level getLevel() {
        return level;
    }

    public int getQuestionNum() {
        return QuestionNum;
    }

    public String getQuestionContent() {
        return QuestionContent;
    }

    public String getSolution1() {
        return Solution1;
    }

    public String getSolution2() {
        return Solution2;
    }
    
    
      public static Vector<Questions> loadQuestionInfo(int LevelNum){
        Connection con = null;
        PreparedStatement s = null;
        ResultSet rs = null;
        Questions q=new Questions();
        Vector <Questions> questions=new Vector<Questions>(); 
       // Random r=new Random();
       // if( LevelNum==1){
         //   r.ints(1,15);  
       // }
        try{
             con = Connect.getConnection();
             String select = "SELECT * FROM think_fast_with_java.questions WHERE LevelNum= ?;";
             s = con.prepareStatement(select);
             s.setInt(1, LevelNum);
             rs = s.executeQuery();
              while (rs.next()) {
                int LevelNum1=rs.getInt("LevelNum");
                int QuestionNum = rs.getInt("QuestionNum");
                String QuestionContent = rs.getString("QuestionContent");
                String Solution1 = rs.getString("Solution1");
                String Solution2 = rs.getString("Solution2");
                q.setQuestionNum(QuestionNum);
                q.setQuestionContent(QuestionContent);
                q.setSolution1(Solution1);
                q.setSolution2(Solution2);
                questions.add(q);
                }
              
           }
           catch(Exception e){
               e.printStackTrace();
           }
           finally{
               if(rs != null) try{rs.close();}catch(Exception e){e.printStackTrace();}
               if(s != null) try{s.close();}catch(Exception e){e.printStackTrace();}
               if(con != null) try{con.close();}catch(Exception e){e.printStackTrace();}
           }        
        return null;
    }
}
