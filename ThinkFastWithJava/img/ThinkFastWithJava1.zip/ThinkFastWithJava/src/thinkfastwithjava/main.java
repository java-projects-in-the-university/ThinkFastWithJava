
package thinkfastwithjava;

import java.sql.Connection;
import java.util.Timer;


public class main {
    public static void main(String[] args) {
        JavaGameForm frame = new JavaGameForm(); 
        PlayerInfo p1 = new PlayerInfo();
        p1.isPlayerExist("Aliaa");
        Timer timer = new Timer();
    } 
}
